//
//  main.m
//  001---MVC架构思路
//
//  Created by cooci on 2018/10/20.
//  Copyright © 2018 cooci. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
