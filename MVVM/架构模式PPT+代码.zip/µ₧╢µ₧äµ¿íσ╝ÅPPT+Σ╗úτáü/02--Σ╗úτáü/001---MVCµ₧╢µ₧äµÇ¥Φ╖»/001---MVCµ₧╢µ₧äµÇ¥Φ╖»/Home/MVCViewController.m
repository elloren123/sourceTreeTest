//
//  MVPViewController.m
//  MVPDemo
//
//  Created by Cooci on 2018/3/31.
//  Copyright © 2018年 Cooci. All rights reserved.
//

#import "MVCViewController.h"
#import "LMDataSource.h"
#import "MVCTableViewCell.h"
#import "Present.h"
#import "Model.h"
#import <YYKit.h>

static NSString *const reuserId = @"reuserId";

@interface MVCViewController ()
@property (nonatomic, strong) UITableView       *tableView;
@property (nonatomic, strong) NSMutableArray    *dataArray;
@property (nonatomic, strong) LMDataSource      *dataSource;
@property (nonatomic, strong) Present           *pt;

@end

@implementation MVCViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.pt = [[Present alloc] init];
    //self.pt.dataArray --- data
    // 集合 -- array
    // 观点 -- 问题 --- 解决 --- 成长
    // cell 复用 ----
    self.dataSource = [[LMDataSource alloc] initWithIdentifier:reuserId configureBlock:^(MVCTableViewCell *cell, Model *model, NSIndexPath *indexPath) {
        // 数据源
        // so easy cell
        // 大众 - 适配器
        // 相同性抽取 --- 抽取 --- cell ---> message --> cellforRowA

        cell.numLabel.text = model.num;
        cell.nameLabel.text= model.name;
        // 通讯 : block 代理  通知 -- runtime
        // 面向协议编程 - MVP
//        cell.model = model;
    }];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.tableView];
    self.tableView.dataSource = self.dataSource;

    [self.dataSource addDataArray:self.pt.dataArray];
    // vc 新人 --- 多人开发 --- 运维成本就高
    // serach
    // .c 4000+
    // model --> view : vc
    // 解重
    // 解耦
    
    [self.tableView reloadData];
}

#pragma mark - lazy

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = [UIColor whiteColor];
        [_tableView registerClass:[MVCTableViewCell class] forCellReuseIdentifier:reuserId];
    }
    return _tableView;
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
