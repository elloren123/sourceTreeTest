//
//  Present.h
//  003--MVP
//
//  Created by Cooci on 2018/4/1.
//  Copyright © 2018年 Cooci. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Model.h"
#import <YYKit.h>

@interface Present : NSObject
@property (nonatomic, strong) NSMutableArray    *dataArray;
@end
