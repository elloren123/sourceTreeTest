
//
//  Present.m
//  003--MVP
//
//  Created by Cooci on 2018/4/1.
//  Copyright © 2018年 Cooci. All rights reserved.
//

#import "Present.h"

@implementation Present

- (instancetype)init{
    if (self = [super init]) {
        [self loadData]; //  是不是不合适
        // 天气 汇率
    }
    return self;
}

// 学习需要努力 --- 小男孩💕小女孩 --- 未来

- (void)loadData{
    
    NSArray *temArray =
    @[
      @{@"name":@"Hank",@"imageUrl":@"http://CC",@"num":@"99"},
      @{@"name":@"Cooci",@"imageUrl":@"http://James",@"num":@"99"},
      @{@"name":@"Kody",@"imageUrl":@"http://Gavin",@"num":@"99"},
      @{@"name":@"小雁子",@"imageUrl":@"http://Cooci",@"num":@"59"},
      @{@"name":@"Lina",@"imageUrl":@"http://Dean ",@"num":@"49"}];
    for (int i = 0; i<temArray.count; i++) {
        Model *m = [Model modelWithDictionary:temArray[i]];
        [self.dataArray addObject:m];
        // 代理 ---
        // UI 需要  叫你
        // 我有 你知道
    }
}

#pragma mark - PresentDelegate
- (void)didClickCellNum:(NSString *)num indexPath:(NSIndexPath *)indexPath{
    
    @synchronized (self) {
        // 数据 --- 数据库 --- 线程不安全 KC --- 信号量 -- 栅栏
        if (indexPath.row < self.dataArray.count) {
            Model *m = self.dataArray[indexPath.row];
            m.num    = num;
        }
        
        if ([num intValue] > 4) {
            // 直接改编数据
            [self.dataArray removeAllObjects];
            NSArray *temArray =
            @[
              @{@"name":@"Hank",@"imageUrl":@"http://CC",@"num":@"99"},
              @{@"name":@"Cooci",@"imageUrl":@"http://James",@"num":@"99"}];
            for (int i = 0; i<temArray.count; i++) {
                Model *m = [Model modelWithDictionary:temArray[i]];
                [self.dataArray addObject:m];
            }
            // 双向绑定
            // 谁实现
            if (self.delegate && [self.delegate respondsToSelector:@selector(reloadUI)]) {
                [self.delegate reloadUI];
            }
        }
        
    }
}

#pragma mark - lazy

- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray arrayWithCapacity:10];
    }
    return _dataArray;
}

@end
