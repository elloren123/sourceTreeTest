//
//  Present.h
//  003--MVP
//
//  Created by Cooci on 2018/4/1.
//  Copyright © 2018年 Cooci. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Model.h"
#import <YYKit.h>


// 重点: 面向协议编程 -- view model
// view model 各自事情处理完毕 ---- 通讯
// 协议 -- 接口 -- 需求
// 清晰代码思路 --- 需求 -- 协议 -- 实现,遵循 --- 面向需求开发 --- 需求驱动代码
// 双向绑定 
@protocol PresentDelegate <NSObject>
// 点击cell num ---> model(self.dataArray[indexPath.row])
@optional // 可选实现的方法
- (void)didClickCellNum:(NSString *)num indexPath:(NSIndexPath *)indexPath;
// 刷新UI
- (void)reloadUI;
@end

//
@interface Present : NSObject<PresentDelegate>
@property (nonatomic, strong) NSMutableArray    *dataArray;
@property(nonatomic, weak) id<PresentDelegate> delegate;

@end
