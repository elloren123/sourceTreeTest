//
//  MVPViewController.m
//  MVPDemo
//
//  Created by Cooci on 2018/3/31.
//  Copyright © 2018年 Cooci. All rights reserved.
//

#import "MVPViewController.h"
#import "LMDataSource.h"
#import "MVPTableViewCell.h"
#import "Model.h"
#import "Present.h"
#import <YYKit.h>

static NSString *const reuserId = @"reuserId";

@interface MVPViewController ()<PresentDelegate>
@property (nonatomic, strong) UITableView       *tableView;
@property (nonatomic, strong) LMDataSource      *dataSource;
@property (nonatomic, strong) Present           *pt;

@end

@implementation MVPViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.pt = [[Present alloc] init]; //  loadData
    __weak typeof(self) weakSelf = self;
    // cell 复用 -- 代理协议 
    self.dataSource = [[LMDataSource alloc] initWithIdentifier:reuserId configureBlock:^(MVPTableViewCell *cell, Model *model, NSIndexPath *indexPath) {
        cell.numLabel.text  = model.num;
        cell.nameLabel.text = model.name;
        cell.delegate       = weakSelf.pt;
        cell.indexPath      = indexPath;
    }];
    [self.dataSource addDataArray:self.pt.dataArray];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.tableView];
    self.tableView.dataSource = self.dataSource;
    self.pt.delegate          = self;
}

#pragma mark - PresentDelegate
- (void)reloadUI{
    [self.dataSource addDataArray:self.pt.dataArray];
    [self.tableView reloadData];
}



#pragma mark - lazy

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = [UIColor whiteColor];
        [_tableView registerClass:[MVPTableViewCell class] forCellReuseIdentifier:reuserId];
    }
    return _tableView;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
