//
//  MVVMView.h
//  002-MVVM
//
//  Created by Cooci on 2018/4/1.
//  Copyright © 2018年 Cooci. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MVVMView : UIView

- (void)headViewWithData:(id)data;

@end
